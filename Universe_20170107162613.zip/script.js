function makeStarName()
{
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

    for( var i=0; i < 5; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}

var planet = function () {
    this.temperature = 16;
    this.atmosphere = false;
    this.name = "Earth";
    this.moons = [];
	this.generate = function(){
        this.temperature = Math.floor((Math.random * 91));
        atmosRand = Math.floor(Math.random * 11)
        if(atmosRand >= 8){
            this.atmosphere = true;
}
        else{
            this.atmosphere = false;
}
}
     this.generateMoons = function(){
        this.numMoons = Math.floor(Math.random * 4);
        index = 96;
        for (i = 0; i < this.numMoons;){
        moon = new planet();
        moon.generate();
        index += 1;
        moon.name = this.name + String.fromCharCode(index);
        this.moons.push(moon);
        console.log("Moon of " + this.name + ": " + moon.name);
        console.log(moon.name + " temperature in Celsius: " + moon.temperature.toString());
        console.log(moon.name + " has atmosphere: " + moon.atmosphere);
}
}
};

var starSystem = function () {
    this.numPlanets = 0;
    this.name = "Sol";
    this.planets = [];
    

this.generate = function(){
    this.numPlanets = Math.floor(Math.random() * 12)
    index = 0;
	this.name = makeStarName();
	console.log("Generating planets for Solar System " + this.name + ": ")
    for(i = 0; i < this.numPlanets;){
        planet1 = new planet();
        planet1.generate();
        index += 1;
        planet1.name = this.name + "-" + index.toString();
        planet1.generateMoons();
        console.log("Planet: " + planet1.name);
console.log(planet.name + " temperature in Celsius: " + planet1.temperature.toString());
        console.log(planet.name + " has atmosphere: " + planet1.atmosphere);
        this.planets.push(planet1);
}
}
};

var galaxySize = 10;
var starSystems = [];
function generateGalaxy(size){
    for(i = 0; i < size;){
        system = new starSystem();
        system.generate();
        console.log(system.name + "System");
        starSystems.push(system);
}
}

generateGalaxy(galaxySize);